data<-iris
str(data)
head(data)
IQR(data$Sepal.Length)
sd(data$Sepal.Length)
var(data$Sepal.Length)
quantile(data$Sepal.Length,0.75)
lapply(data[,1:4],sd)

getmode <- function(v)
{
  uniqv<-unique(v)
  uniqv[which.max(tabulate(match(v,uniqv)))]
}

getmode(data$Sepal.Length)