N=5000
n=20
sum=0
for(val in 1:N)
{
  a=as.integer(any(duplicated(sample(365,n,replace=TRUE))))
  sum=sum+a
}
prob=sum/N
print(prob)
