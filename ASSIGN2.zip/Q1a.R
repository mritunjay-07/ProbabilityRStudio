chest<-c(rep("gold",20),rep("silver",30),rep("bronze",50))
print(sample(chest,10))

