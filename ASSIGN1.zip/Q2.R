n=as.integer(readline(prompt = "Enter a Number: "))
fact=1
num=n
if(num < 0)
{
  print("The Input Number is Negative")
} else {
  while(num)
  {
    fact=fact*num
    num=num-1
  }
  print(paste("Factorial of ",n," is ",fact))
}