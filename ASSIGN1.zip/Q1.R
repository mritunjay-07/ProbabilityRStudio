x=c(5,10,15,20,25,30)
print(paste("Maximum Value of x is ",max(x)))
print(paste("Minimum Value of x is ",min(x)))