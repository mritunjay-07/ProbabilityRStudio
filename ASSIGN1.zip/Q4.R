add <- function(x,y){
  return (x+y)
}
sub <- function(x,y){
  return (x-y)
}
mult <- function(x,y){
  return (x*y)
}
div <- function(x,y){
  return (x/y)
}

print("Calculator....")
print("1 for Addition")
print("2 for Substraction")
print("3 for Multiplication")
print("4 for Divison")
ch=as.integer(readline(prompt = "Enter your choice : "))
a=as.integer(readline(prompt = "Enter Number 1 : "))
b=as.integer(readline(prompt = "Enter Number 2 : "))
result=switch(ch,
              "1"=add(a,b),
              "2"=sub(a,b),
              "3"=mult(a,b),
              "4"=div(a,b))
print(paste("Answer is : ",result))