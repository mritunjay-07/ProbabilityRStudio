x1=c(5,7,8,7,22,9,4,11,12,9,6)
y1=c(99,86,87,111,103,87,94,78,77,85,86)
x2=c(2,2,8,1,15,8,12,9,7,3,11,4,7)
y2=c(100,105,84,105,90,99,90,95,94,100,79,112,91)

plot(x1,y1,main="Observation of Cars",xlab="Car Age",ylab="Car Speed",col="red")
points(x2,y2,col="blue")

Expenses=c(7000,3000,800,2000,1900,300)
Labels=c("Rent","Grocery","Transport","School Fees","Savings","Current")

pie(Expenses,labels = Labels,main="Expenses",col=rainbow(24))

barplot(y1,names.arg=x1,main="Observation of Cars",xlab="Car Age",ylab="Car Speed")
