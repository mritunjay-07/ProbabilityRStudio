n=as.integer(readline(prompt = "Enter a Number: "))
a=0
b=1
if(n<0)
{
  print("Number of terms can't be Negative")
} else
{
if(n==1)
{
print(paste("First",n,"terms of Fibbonacci Sequence is ",a))
} else
{
  cat(paste("First",n,"terms of Fibbonacci Sequence is ",a,b,""))
  for(i in 1:(n-2))
  {
    c=a+b
    cat(c)
    cat(" ")
    a=b
    b=c
  }
}
}